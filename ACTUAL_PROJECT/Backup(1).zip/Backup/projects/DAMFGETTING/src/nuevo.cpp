#include <cstdio>
#include <cstdlib>

void Print_Data(){
	printf("Hellow_World");
}

