#include <RF24DP.h>
#include <delay.h>
#include <cstdio>

RF24DP FireComm(22,0);

char CommCheck(char casea, char casef,char casen  ){
		if((FireComm.RF24DPRead()==Comm_received)){  //Was an Alarm code received?
			int AUX=FireComm.Get_Code();
			if(AUX==Alarm_Mode){
				return casea;
			}	
			else if(AUX==Fail_Mode){
					return casef;
			}		
			else if(AUX==Normal_Mode){
				return casen;
			}							//Set the UART Flag interaction
		}
		else if(FireComm.RF24DPRead()==Comm_timeout){//The UART Listening timeout was reached?
			return 5;										//monitor Fail codes
		}
		return 2;
}		

int main(int argc, char** argv)
{	
	FireComm.Init(); //Initialize uart1 through UART_USB
	FireComm.Set_Up(15,15,115); //Initialize uart1 through UART_USB
	char fire=10;
	char fail=50;
	char normal=100;
	delay_t delayloop;
	delayInit(&delayloop,2000);
	char aux=0;
	while(1){
		
	
		FireComm.RF24DPUpdate();
		aux=CommCheck(fire,fail,normal);
		if(aux!=5 && aux!=2){
				FireComm.RF24DPReset();
				printf("Translation : %d \n",aux);
		}		
		if(delayRead(&delayloop)){
			if(aux==5){
				printf("Timeout\n");
				delayInit(&delayloop,1000);
				FireComm.RF24DPReset();
			}
			
		}
	}
}
