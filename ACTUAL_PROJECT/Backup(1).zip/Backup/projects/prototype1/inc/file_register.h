#include <stdio.h>

#ifndef FREGISTER_H
#define FREGISTER_H

#ifdef __cplusplus
extern "C" {
#endif

void Text_Init(char *name  );
void Text_Write(char *text  );


#ifdef __cplusplus
}
#endif
#endif 

