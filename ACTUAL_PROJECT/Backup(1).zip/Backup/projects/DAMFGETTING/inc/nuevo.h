#if !defined( NUEVO_H )
#define NUEVO_H

#include <cstdlib>

void Print_Data();


#endif
